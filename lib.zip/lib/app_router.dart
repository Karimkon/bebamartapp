// lib/app_router.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'features/auth/providers/auth_provider.dart';
import 'features/auth/screens/splash_screen.dart';
import 'features/auth/screens/login_screen.dart';
import 'features/auth/screens/register_screen.dart';
import 'features/buyer/screens/buyer_shell.dart';
import 'features/buyer/screens/home_screen.dart';
import 'features/buyer/screens/cart_screen.dart';
import 'features/buyer/screens/orders_screen.dart';
import 'features/buyer/screens/profile_screen.dart';
import 'features/buyer/screens/product_detail_screen.dart';
import 'features/buyer/screens/wishlist_screen.dart';
import 'features/vendor/screens/vendor_shell.dart';
import 'features/vendor/screens/vendor_dashboard_screen.dart';
import 'features/vendor/screens/vendor_products_screen.dart';
import 'features/vendor/screens/vendor_orders_screen.dart';
import 'features/vendor/screens/vendor_profile_screen.dart';
import 'features/chat/screens/chat_list_screen.dart';
import 'features/chat/screens/chat_detail_screen.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authProvider);
  
  return GoRouter(
    initialLocation: '/splash',
    debugLogDiagnostics: true,
    redirect: (context, state) {
      final isAuthenticated = authState.isAuthenticated;
      final isLoading = authState.status == AuthStatus.unknown;
      final currentPath = state.uri.path;

      // While we don't know auth status, show splash
      if (isLoading) return '/splash';

      final isAuthRoute = currentPath == '/login' || currentPath == '/register' || currentPath == '/vendor-register';
      // Treat product detail as public, but NOT the splash — splash should only appear while loading
      final isPublicRoute = currentPath.startsWith('/product');

      // If user is not authenticated, send them to login (unless they're already on an auth route or viewing a public product)
      if (!isAuthenticated && !isAuthRoute && !isPublicRoute) {
        return '/login';
      }

      // Prevent navigating back to auth routes when already authenticated
      if (isAuthenticated && isAuthRoute) {
        return authState.isVendor ? '/vendor' : '/';
      }

      return null;
    },
    routes: [
      GoRoute(path: '/splash', builder: (_, __) => const SplashScreen()),
      GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/register', builder: (_, __) => const RegisterScreen()),
      GoRoute(path: '/vendor-register', builder: (_, __) => const RegisterScreen(isVendor: true)),
      
      // Buyer Shell
      ShellRoute(
        builder: (_, __, child) => BuyerShell(child: child),
        routes: [
          GoRoute(path: '/', builder: (_, __) => const HomeScreen()),
          GoRoute(path: '/cart', builder: (_, __) => const CartScreen()),
          GoRoute(path: '/wishlist', builder: (_, __) => const WishlistScreen()),
          GoRoute(path: '/orders', builder: (_, __) => const OrdersScreen()),
          GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
        ],
      ),
      
      GoRoute(
        path: '/product/:id',
        builder: (_, state) => ProductDetailScreen(productId: int.parse(state.pathParameters['id']!)),
      ),
      
      GoRoute(path: '/chat', builder: (_, __) => const ChatListScreen()),
      GoRoute(
        path: '/chat/:id',
        builder: (_, state) => ChatDetailScreen(conversationId: int.parse(state.pathParameters['id']!)),
      ),
      
      // Vendor Shell
      ShellRoute(
        builder: (_, __, child) => VendorShell(child: child),
        routes: [
          GoRoute(path: '/vendor', builder: (_, __) => const VendorDashboardScreen()),
          GoRoute(path: '/vendor/products', builder: (_, __) => const VendorProductsScreen()),
          GoRoute(path: '/vendor/orders', builder: (_, __) => const VendorOrdersScreen()),
          GoRoute(path: '/vendor/profile', builder: (_, __) => const VendorProfileScreen()),
        ],
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            Text('Page not found: ${state.uri.path}'),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: () => context.go('/'), child: const Text('Go Home')),
          ],
        ),
      ),
    ),
  );
});
