// lib/shared/models/category_model.dart
// Category model mapped 1:1 with Laravel categories table

class CategoryModel {
  final int id;
  final String name;
  final String slug;
  final String? description;
  final String? icon;
  final String? image;
  final bool isActive;
  final int? parentId;
  final int sortOrder;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  
  // Relationships
  final CategoryModel? parent;
  final List<CategoryModel> children;
  final int? listingsCount;
  
  CategoryModel({
    required this.id,
    required this.name,
    required this.slug,
    this.description,
    this.icon,
    this.image,
    this.isActive = true,
    this.parentId,
    this.sortOrder = 0,
    this.createdAt,
    this.updatedAt,
    this.parent,
    this.children = const [],
    this.listingsCount,
  });
  
  factory CategoryModel.fromJson(Map<String, dynamic> json) {
    return CategoryModel(
      id: json['id'] as int,
      name: json['name'] as String,
      slug: json['slug'] as String,
      description: json['description'] as String?,
      icon: json['icon'] as String?,
      image: json['image'] as String?,
      isActive: json['is_active'] == true || json['is_active'] == 1,
      parentId: json['parent_id'] as int?,
      sortOrder: json['sort_order'] as int? ?? 0,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : null,
      parent: json['parent'] != null
          ? CategoryModel.fromJson(json['parent'])
          : null,
      children: (json['children'] as List<dynamic>?)
          ?.map((e) => CategoryModel.fromJson(e))
          .toList() ?? [],
      listingsCount: json['listings_count'] as int?,
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'slug': slug,
      'description': description,
      'icon': icon,
      'image': image,
      'is_active': isActive,
      'parent_id': parentId,
      'sort_order': sortOrder,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
  
  bool get hasParent => parentId != null;
  bool get hasChildren => children.isNotEmpty;
  bool get isParent => parentId == null;
  
  String get displayListingsCount {
    if (listingsCount == null) return '';
    return listingsCount == 1 ? '1 item' : '$listingsCount items';
  }
}

// Service Category model for Jobs & Services (mapped to service_categories table)
class ServiceCategoryModel {
  final int id;
  final String name;
  final String slug;
  final String? description;
  final String? icon;
  final String? image;
  final int? parentId;
  final String type; // job, service
  final bool isActive;
  final int sortOrder;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  
  ServiceCategoryModel({
    required this.id,
    required this.name,
    required this.slug,
    this.description,
    this.icon,
    this.image,
    this.parentId,
    required this.type,
    this.isActive = true,
    this.sortOrder = 0,
    this.createdAt,
    this.updatedAt,
  });
  
  factory ServiceCategoryModel.fromJson(Map<String, dynamic> json) {
    return ServiceCategoryModel(
      id: json['id'] as int,
      name: json['name'] as String,
      slug: json['slug'] as String,
      description: json['description'] as String?,
      icon: json['icon'] as String?,
      image: json['image'] as String?,
      parentId: json['parent_id'] as int?,
      type: json['type'] as String? ?? 'job',
      isActive: json['is_active'] == true || json['is_active'] == 1,
      sortOrder: json['sort_order'] as int? ?? 0,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : null,
    );
  }
  
  bool get isJobCategory => type == 'job';
  bool get isServiceCategory => type == 'service';
}
