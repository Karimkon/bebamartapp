// lib/shared/models/listing_model.dart
// Listing model mapped 1:1 with Laravel listings table

import 'user_model.dart';
import 'category_model.dart';

class ListingModel {
  final int id;
  final int vendorProfileId;
  final String title;
  final String? description;
  final String? sku;
  final double price;
  final double? weightKg;
  final String? origin;
  final String? condition;
  final int? categoryId;
  final int stock;
  final Map<String, dynamic>? attributes;
  final bool isActive;
  final int viewCount;
  final int clickCount;
  final int wishlistCount;
  final int cartAddCount;
  final int purchaseCount;
  final int shareCount;
  final DateTime? lastViewedAt;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  
  // Relationships
  final VendorProfileModel? vendor;
  final CategoryModel? category;
  final List<ListingImageModel> images;
  final List<ListingVariantModel> variants;
  final List<ReviewModel>? reviews;
  
  // Computed properties from Laravel
  final double? averageRating;
  final int? reviewsCount;
  
  ListingModel({
    required this.id,
    required this.vendorProfileId,
    required this.title,
    this.description,
    this.sku,
    required this.price,
    this.weightKg,
    this.origin,
    this.condition,
    this.categoryId,
    this.stock = 0,
    this.attributes,
    this.isActive = true,
    this.viewCount = 0,
    this.clickCount = 0,
    this.wishlistCount = 0,
    this.cartAddCount = 0,
    this.purchaseCount = 0,
    this.shareCount = 0,
    this.lastViewedAt,
    this.createdAt,
    this.updatedAt,
    this.vendor,
    this.category,
    this.images = const [],
    this.variants = const [],
    this.reviews,
    this.averageRating,
    this.reviewsCount,
  });
  
  factory ListingModel.fromJson(Map<String, dynamic> json) {
    return ListingModel(
      id: json['id'] as int,
      vendorProfileId: json['vendor_profile_id'] as int,
      title: json['title'] as String,
      description: json['description'] as String?,
      sku: json['sku'] as String?,
      price: (json['price'] as num).toDouble(),
      weightKg: (json['weight_kg'] as num?)?.toDouble(),
      origin: json['origin'] as String?,
      condition: json['condition'] as String?,
      categoryId: json['category_id'] as int?,
      stock: json['stock'] as int? ?? 0,
      attributes: json['attributes'] is Map<String, dynamic> 
          ? json['attributes'] 
          : null,
      isActive: json['is_active'] == true || json['is_active'] == 1,
      viewCount: json['view_count'] as int? ?? 0,
      clickCount: json['click_count'] as int? ?? 0,
      wishlistCount: json['wishlist_count'] as int? ?? 0,
      cartAddCount: json['cart_add_count'] as int? ?? 0,
      purchaseCount: json['purchase_count'] as int? ?? 0,
      shareCount: json['share_count'] as int? ?? 0,
      lastViewedAt: json['last_viewed_at'] != null
          ? DateTime.parse(json['last_viewed_at'])
          : null,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : null,
      vendor: json['vendor'] != null
          ? VendorProfileModel.fromJson(json['vendor'])
          : null,
      category: json['category'] != null
          ? CategoryModel.fromJson(json['category'])
          : null,
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => ListingImageModel.fromJson(e))
          .toList() ?? [],
      variants: (json['variants'] as List<dynamic>?)
          ?.map((e) => ListingVariantModel.fromJson(e))
          .toList() ?? [],
      reviews: (json['reviews'] as List<dynamic>?)
          ?.map((e) => ReviewModel.fromJson(e))
          .toList(),
      averageRating: (json['average_rating'] as num?)?.toDouble(),
      reviewsCount: json['reviews_count'] as int?,
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'vendor_profile_id': vendorProfileId,
      'title': title,
      'description': description,
      'sku': sku,
      'price': price,
      'weight_kg': weightKg,
      'origin': origin,
      'condition': condition,
      'category_id': categoryId,
      'stock': stock,
      'attributes': attributes,
      'is_active': isActive,
      'view_count': viewCount,
      'click_count': clickCount,
      'wishlist_count': wishlistCount,
      'cart_add_count': cartAddCount,
      'purchase_count': purchaseCount,
      'share_count': shareCount,
      'last_viewed_at': lastViewedAt?.toIso8601String(),
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }
  
  // Computed properties matching Laravel model
  bool get hasVariations => variants.where((v) => v.stock > 0).isNotEmpty;
  
  List<String> get availableColors => variants
      .where((v) => v.stock > 0)
      .map((v) => v.color)
      .where((c) => c != null)
      .cast<String>()
      .toSet()
      .toList();
  
  List<String> get availableSizes => variants
      .where((v) => v.stock > 0)
      .map((v) => v.size)
      .where((s) => s != null)
      .cast<String>()
      .toSet()
      .toList();
  
  String? get primaryImage => images.isNotEmpty ? images.first.fullPath : null;
  
  double get displayRating => averageRating ?? 0.0;
  
  int get displayReviewsCount => reviewsCount ?? 0;
  
  bool get isInStock => stock > 0 || hasVariations;
  
  String get formattedPrice => 'UGX ${price.toStringAsFixed(0)}';
  
  ListingVariantModel? findVariantByAttributes(String? color, String? size) {
    return variants.firstWhere(
      (v) {
        final colorMatch = color == null || v.color == color;
        final sizeMatch = size == null || v.size == size;
        return colorMatch && sizeMatch;
      },
      orElse: () => variants.isNotEmpty ? variants.first : throw StateError('No variants'),
    );
  }
  
  ListingVariantModel? get defaultVariant => 
      variants.where((v) => v.isDefault).firstOrNull ?? variants.firstOrNull;
}

// ListingImage model mapped to listing_images table
class ListingImageModel {
  final int id;
  final int listingId;
  final String path;
  final int? sortOrder;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  
  ListingImageModel({
    required this.id,
    required this.listingId,
    required this.path,
    this.sortOrder,
    this.createdAt,
    this.updatedAt,
  });
  
  factory ListingImageModel.fromJson(Map<String, dynamic> json) {
    return ListingImageModel(
      id: json['id'] as int,
      listingId: json['listing_id'] as int,
      path: json['path'] as String,
      sortOrder: json['sort_order'] as int?,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : null,
    );
  }
  
  // Get full URL for image
  String get fullPath {
    if (path.startsWith('http')) return path;
    // Remove leading slash if present
    final cleanPath = path.startsWith('/') ? path.substring(1) : path;
    return 'storage/$cleanPath';
  }
}

// ListingVariant model mapped to listing_variants table
class ListingVariantModel {
  final int id;
  final int listingId;
  final String? sku;
  final double price;
  final double? displayPrice;
  final int stock;
  final Map<String, dynamic>? attributes;
  final bool isDefault;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  
  ListingVariantModel({
    required this.id,
    required this.listingId,
    this.sku,
    required this.price,
    this.displayPrice,
    this.stock = 0,
    this.attributes,
    this.isDefault = false,
    this.createdAt,
    this.updatedAt,
  });
  
  factory ListingVariantModel.fromJson(Map<String, dynamic> json) {
    return ListingVariantModel(
      id: json['id'] as int,
      listingId: json['listing_id'] as int,
      sku: json['sku'] as String?,
      price: (json['price'] as num).toDouble(),
      displayPrice: (json['display_price'] as num?)?.toDouble(),
      stock: json['stock'] as int? ?? 0,
      attributes: json['attributes'] is Map<String, dynamic>
          ? json['attributes']
          : null,
      isDefault: json['is_default'] == true || json['is_default'] == 1,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : null,
    );
  }
  
  String? get color => attributes?['color'] as String?;
  String? get size => attributes?['size'] as String?;
  
  double get effectivePrice => displayPrice ?? price;
  
  String get formattedPrice => 'UGX ${effectivePrice.toStringAsFixed(0)}';
}

// Review model mapped to reviews table
class ReviewModel {
  final int id;
  final int userId;
  final int listingId;
  final int? orderId;
  final int rating;
  final String? title;
  final String? comment;
  final String status; // pending, approved, rejected
  final String? vendorResponse;
  final DateTime? vendorResponseAt;
  final int helpfulVotes;
  final int unhelpfulVotes;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  
  // Relationships
  final UserModel? user;
  final ListingModel? listing;
  
  ReviewModel({
    required this.id,
    required this.userId,
    required this.listingId,
    this.orderId,
    required this.rating,
    this.title,
    this.comment,
    this.status = 'pending',
    this.vendorResponse,
    this.vendorResponseAt,
    this.helpfulVotes = 0,
    this.unhelpfulVotes = 0,
    this.createdAt,
    this.updatedAt,
    this.user,
    this.listing,
  });
  
  factory ReviewModel.fromJson(Map<String, dynamic> json) {
    return ReviewModel(
      id: json['id'] as int,
      userId: json['user_id'] as int,
      listingId: json['listing_id'] as int,
      orderId: json['order_id'] as int?,
      rating: json['rating'] as int,
      title: json['title'] as String?,
      comment: json['comment'] as String?,
      status: json['status'] as String? ?? 'pending',
      vendorResponse: json['vendor_response'] as String?,
      vendorResponseAt: json['vendor_response_at'] != null
          ? DateTime.parse(json['vendor_response_at'])
          : null,
      helpfulVotes: json['helpful_votes'] as int? ?? 0,
      unhelpfulVotes: json['unhelpful_votes'] as int? ?? 0,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'])
          : null,
      updatedAt: json['updated_at'] != null
          ? DateTime.parse(json['updated_at'])
          : null,
      user: json['user'] != null
          ? UserModel.fromJson(json['user'])
          : null,
      listing: json['listing'] != null
          ? ListingModel.fromJson(json['listing'])
          : null,
    );
  }
  
  bool get isApproved => status == 'approved';
  bool get hasVendorResponse => vendorResponse != null && vendorResponse!.isNotEmpty;
}
