// lib/features/buyer/providers/listing_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';
import '../../../core/network/api_client.dart';
import '../../../core/constants/app_constants.dart';
import '../../../shared/models/listing_model.dart';
import '../../auth/providers/auth_provider.dart';

// Featured listings provider
final featuredListingsProvider = FutureProvider<List<ListingModel>>((ref) async {
  print('🔄 featuredListingsProvider: Fetching featured listings...');
  final api = ref.watch(apiClientProvider);
  
  try {
    final response = await api.get(ApiEndpoints.featuredListings);
    print('📦 featuredListingsProvider: Response status: ${response.statusCode}');
    
    if (response.statusCode == 200) {
      List<dynamic> listingsData = [];
      
      if (response.data is Map && (response.data as Map)['success'] == true) {
        listingsData = (response.data as Map)['data'] ?? [];
        print('✅ Found ${listingsData.length} listings in data key');
      } else if (response.data is List) {
        listingsData = response.data;
        print('✅ Response is direct list with ${listingsData.length} items');
      } else {
        print('⚠️ Unexpected response format: ${response.data}');
        return [];
      }
      
      if (listingsData.isEmpty) {
        print('⚠️ No featured listings found');
        return [];
      }
      
      try {
        final listings = listingsData.map<ListingModel>((item) {
          return ListingModel(
            id: item['id'] ?? 0,
            title: item['title'] ?? 'Unknown Product',
            description: item['description'] ?? '',
            price: (item['price'] ?? 0).toDouble(),
            formattedPrice: 'UGX ${(item['price'] ?? 0).toString()}',
            primaryImage: item['thumbnail'],
            stock: item['stock'] ?? 0,
            rating: (item['rating'] ?? 0.0).toDouble(),
            displayRating: (item['rating'] ?? 0.0).toDouble(),
            reviewsCount: item['reviews_count'] ?? 0,
            displayReviewsCount: item['reviews_count'] ?? 0,
            vendor: item['vendor'] != null
                ? VendorInfo(
                    businessName: item['vendor']['businessName'] ?? 
                                  item['vendor']['store_name'] ?? 
                                  'Unknown Vendor',
                  )
                : null,
            category: item['category'] != null
                ? CategoryInfo(
                    id: item['category']['id'] ?? 0,
                    name: item['category']['name'] ?? 'General',
                    slug: item['category']['slug'] ?? 'general',
                  )
                : null,
          );
        }).where((listing) => listing.id != 0).toList();
        
        print('✅ Successfully parsed ${listings.length} featured listings');
        return listings;
      } catch (e, stack) {
        print('❌ Error parsing listings: $e');
        print('📋 Stack: $stack');
        return [];
      }
    }
    
    print('❌ Failed to load featured listings: ${response.statusCode}');
    return [];
  } on DioException catch (e) {
    print('❌ DioException in featuredListingsProvider: ${e.message}');
    return [];
  } catch (e) {
    print('❌ Error in featuredListingsProvider: $e');
    return [];
  }
});

// Marketplace listings
final marketplaceListingsProvider = FutureProvider.family<List<ListingModel>, Map<String, dynamic>>((ref, filters) async {
  final api = ref.watch(apiClientProvider);
  
  try {
    final response = await api.get(
      ApiEndpoints.marketplace,
      queryParameters: filters,
    );
    
    if (response.statusCode == 200 && response.data is Map) {
      if (response.data['success'] == true) {
        final listingsData = (response.data['data'] as List?) ?? [];
        return listingsData
            .map((e) => ListingModel.fromJson(e))
            .where((listing) => listing.id != 0)
            .toList();
      }
    }
    return [];
  } on DioException catch (e) {
    throw Exception('Failed to load listings: ${e.message}');
  }
});

// Single listing provider
final listingDetailProvider = FutureProvider.family<ListingModel?, int>((ref, id) async {
  final api = ref.watch(apiClientProvider);
  
  try {
    final response = await api.get(ApiEndpoints.listingDetail(id));
    
    if (response.statusCode == 200 && response.data is Map) {
      if (response.data['success'] == true) {
        return ListingModel.fromJson(response.data['data']);
      }
    }
    return null;
  } on DioException catch (e) {
    throw Exception('Failed to load listing: ${e.message}');
  }
});

// Search listings
class SearchState {
  final List<ListingModel> results;
  final bool isLoading;
  final String? error;
  final String query;

  const SearchState({
    this.results = const [],
    this.isLoading = false,
    this.error,
    this.query = '',
  });

  SearchState copyWith({
    List<ListingModel>? results,
    bool? isLoading,
    String? error,
    String? query,
  }) {
    return SearchState(
      results: results ?? this.results,
      isLoading: isLoading ?? this.isLoading,
      error: error,
      query: query ?? this.query,
    );
  }
}

class SearchNotifier extends StateNotifier<SearchState> {
  final ApiClient _api;

  SearchNotifier(this._api) : super(const SearchState());

  Future<void> search(String query) async {
    if (query.isEmpty) {
      state = const SearchState();
      return;
    }

    state = state.copyWith(isLoading: true, query: query, error: null);

    try {
      final response = await _api.get(
        ApiEndpoints.marketplace,
        queryParameters: {'search': query},
      );

      if (response.statusCode == 200 && response.data is Map) {
        if (response.data['success'] == true) {
          final listingsData = (response.data['data'] as List?) ?? [];
          final results = listingsData
              .map((e) => ListingModel.fromJson(e))
              .where((listing) => listing.id != 0)
              .toList();
          state = state.copyWith(results: results, isLoading: false);
          return;
        }
      }
      state = state.copyWith(isLoading: false, error: 'No results found');
    } on DioException catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: e.message ?? 'Search failed',
      );
    }
  }

  void clear() {
    state = const SearchState();
  }
}

final searchProvider = StateNotifierProvider<SearchNotifier, SearchState>((ref) {
  final api = ref.watch(apiClientProvider);
  return SearchNotifier(api);
});

// Listing by category
final listingsByCategoryProvider = FutureProvider.family<List<ListingModel>, String>((ref, slug) async {
  final api = ref.watch(apiClientProvider);
  
  try {
    final response = await api.get(ApiEndpoints.categoryDetail(slug));
    
    if (response.statusCode == 200 && response.data is Map) {
      if (response.data['success'] == true) {
        final listingsData = (response.data['data'] as List?) ?? [];
        return listingsData
            .map((e) => ListingModel.fromJson(e))
            .where((listing) => listing.id != 0)
            .toList();
      }
    }
    return [];
  } on DioException catch (e) {
    throw Exception('Failed to load listings: ${e.message}');
  }
});

// Simple helper classes for vendor and category info
class VendorInfo {
  final String businessName;
  
  VendorInfo({required this.businessName});
}

class CategoryInfo {
  final int id;
  final String name;
  final String slug;
  
  CategoryInfo({required this.id, required this.name, required this.slug});
}